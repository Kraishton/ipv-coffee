import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useData } from "@/contexts/DataContext";
import { formatCurrency, formatCurrencyFull, formatPercent } from "@/utils/format";

function InfoRow({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color?: string;
}) {
  const colors = useColors();
  return (
    <View style={styles.infoRow}>
      <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.infoValue, { color: color ?? colors.foreground }]}>{value}</Text>
    </View>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  const colors = useColors();
  return (
    <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>
      <View style={[styles.divider, { backgroundColor: colors.border }]} />
      {children}
    </View>
  );
}

export default function PeriodDetail() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { periods, loading } = useData();

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} size="large" />
      </View>
    );
  }

  const idx = parseInt(id ?? "0", 10);
  const period = periods[idx];

  if (!period) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.foreground }}>Período no encontrado</Text>
      </View>
    );
  }

  const margen = formatPercent(period.utilidad_bruta, period.ventas);
  const topProducts = [...period.products]
    .sort((a, b) => b.importe - a.importe)
    .slice(0, 10);
  const maxDayVenta = Math.max(...period.daily_ventas.map((d) => d.monto), 1);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.navBar,
          {
            paddingTop: insets.top + (Platform.OS === "web" ? 67 : 8),
            backgroundColor: colors.background,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [styles.backBtn, { opacity: pressed ? 0.6 : 1 }]}
        >
          <Feather name="arrow-left" size={22} color={colors.primary} />
        </Pressable>
        <Text style={[styles.navTitle, { color: colors.foreground }]} numberOfLines={1}>
          {period.periodo}
        </Text>
        <View style={{ width: 36 }} />
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 40) },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero */}
        <View style={[styles.hero, { backgroundColor: colors.primary }]}>
          <Text style={styles.heroLabel}>Ventas Totales</Text>
          <Text style={styles.heroVentas}>{formatCurrencyFull(period.ventas)}</Text>
          <View style={styles.heroRow}>
            <View style={styles.heroStat}>
              <Text style={styles.heroStatLabel}>Costo</Text>
              <Text style={styles.heroStatValue}>{formatCurrencyFull(period.costo)}</Text>
            </View>
            <View style={styles.heroDivider} />
            <View style={styles.heroStat}>
              <Text style={styles.heroStatLabel}>Utilidad</Text>
              <Text style={styles.heroStatValue}>{formatCurrencyFull(period.utilidad_bruta)}</Text>
            </View>
            <View style={styles.heroDivider} />
            <View style={styles.heroStat}>
              <Text style={styles.heroStatLabel}>Margen</Text>
              <Text style={styles.heroStatValue}>{margen}</Text>
            </View>
          </View>
        </View>

        {/* Financiero */}
        <Section title="Financiero">
          <InfoRow label="Ventas netas" value={formatCurrencyFull(period.ventas)} />
          <InfoRow label="Costo total" value={formatCurrencyFull(period.costo)} color={colors.destructive} />
          <InfoRow label="Utilidad bruta" value={formatCurrencyFull(period.utilidad_bruta)} color={colors.success} />
          <InfoRow label="Efectivo a llevar" value={formatCurrencyFull(period.efectivo)} />
          <InfoRow label="Inversión restante" value={formatCurrencyFull(period.inversion)} color={colors.accent} />
          <InfoRow
            label={period.sobrante >= 0 ? "Sobrante" : "Faltante"}
            value={formatCurrencyFull(Math.abs(period.sobrante))}
            color={period.sobrante >= 0 ? colors.success : colors.destructive}
          />
        </Section>

        {/* Distribución de Utilidades */}
        <Section title="Distribución de Utilidades">
          <View style={[styles.partnerCard, { backgroundColor: colors.muted }]}>
            <View style={styles.partnerHeader}>
              <Feather name="user" size={16} color={colors.primary} />
              <Text style={[styles.partnerName, { color: colors.foreground }]}>Orly</Text>
            </View>
            <Text style={[styles.partnerAmount, { color: colors.primary }]}>
              {formatCurrencyFull(period.utilidad_orly)}
            </Text>
            {period.orly_items.length > 0 && (
              <View style={styles.itemsList}>
                {period.orly_items.map((it, i) => (
                  <Text key={i} style={[styles.itemText, { color: colors.mutedForeground }]}>
                    · {it.item} ×{it.qty}
                  </Text>
                ))}
              </View>
            )}
          </View>
          <View style={{ height: 10 }} />
          <View style={[styles.partnerCard, { backgroundColor: colors.muted }]}>
            <View style={styles.partnerHeader}>
              <Feather name="user" size={16} color={colors.accent} />
              <Text style={[styles.partnerName, { color: colors.foreground }]}>Alejandro</Text>
            </View>
            <Text style={[styles.partnerAmount, { color: colors.accent }]}>
              {formatCurrencyFull(period.utilidad_alejandro)}
            </Text>
            {period.ale_items.length > 0 && (
              <View style={styles.itemsList}>
                {period.ale_items.map((it, i) => (
                  <Text key={i} style={[styles.itemText, { color: colors.mutedForeground }]}>
                    · {it.item} ×{it.qty}
                  </Text>
                ))}
              </View>
            )}
          </View>
        </Section>

        {/* Pagos y Gastos */}
        <Section title="Pagos y Gastos">
          <InfoRow label="Salario dependiente" value={formatCurrencyFull(period.salario)} />
          {period.faltante > 0 && (
            <InfoRow label="Faltante" value={formatCurrencyFull(period.faltante)} color={colors.destructive} />
          )}
          <InfoRow label="Seguridad" value={formatCurrencyFull(period.seguridad)} />
          <InfoRow label="Económico" value={formatCurrencyFull(period.economico)} />
        </Section>

        {/* Ventas diarias */}
        {period.daily_ventas.filter((d) => d.monto > 0).length > 0 && (
          <Section title="Ventas por Día">
            {period.daily_ventas
              .filter((d) => d.monto > 0)
              .map((d, i) => (
                <View key={i} style={styles.dayRow}>
                  <Text style={[styles.dayName, { color: colors.mutedForeground }]}>{d.dia}</Text>
                  <View style={styles.dayBarWrap}>
                    <View
                      style={[
                        styles.dayBar,
                        {
                          backgroundColor: colors.primary,
                          width: `${Math.max(4, (d.monto / maxDayVenta) * 100)}%`,
                        },
                      ]}
                    />
                  </View>
                  <Text style={[styles.dayAmount, { color: colors.foreground }]}>
                    {formatCurrency(d.monto)}
                  </Text>
                </View>
              ))}
          </Section>
        )}

        {/* Top productos */}
        {topProducts.length > 0 && (
          <Section title={`Top ${topProducts.length} Productos — toca para ver historial`}>
            {topProducts.map((p, i) => (
              <Pressable
                key={i}
                style={({ pressed }) => [
                  styles.productRow,
                  {
                    backgroundColor: pressed ? colors.muted : "transparent",
                    borderRadius: 10,
                    marginHorizontal: -6,
                    paddingHorizontal: 6,
                  },
                ]}
                onPress={() =>
                  router.push({
                    pathname: "/product/[name]",
                    params: { name: encodeURIComponent(p.producto) },
                  })
                }
              >
                <View style={[styles.prodRank, { backgroundColor: i < 3 ? colors.primary : colors.muted }]}>
                  <Text style={[styles.prodRankText, { color: i < 3 ? "#fff" : colors.mutedForeground }]}>
                    {i + 1}
                  </Text>
                </View>
                <Text style={[styles.prodName, { color: colors.foreground }]} numberOfLines={1}>
                  {p.producto}
                </Text>
                <Text style={[styles.prodAmount, { color: colors.foreground }]}>
                  {formatCurrency(p.importe)}
                </Text>
                <Feather name="chevron-right" size={14} color={colors.mutedForeground} />
              </Pressable>
            ))}
          </Section>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  navBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    gap: 8,
  },
  backBtn: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
  },
  navTitle: {
    flex: 1,
    fontFamily: "Inter_700Bold",
    fontSize: 17,
    textAlign: "center",
    letterSpacing: -0.3,
  },
  content: { padding: 20, gap: 16 },
  hero: { borderRadius: 18, padding: 20 },
  heroLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 11,
    color: "rgba(255,255,255,0.7)",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: 6,
  },
  heroVentas: {
    fontFamily: "Inter_700Bold",
    fontSize: 36,
    color: "#fff",
    letterSpacing: -1,
    marginBottom: 16,
  },
  heroRow: { flexDirection: "row", alignItems: "center" },
  heroStat: { flex: 1, alignItems: "center" },
  heroStatLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 11,
    color: "rgba(255,255,255,0.65)",
    marginBottom: 4,
  },
  heroStatValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
    color: "#fff",
    letterSpacing: -0.3,
  },
  heroDivider: { width: 1, height: 32, backgroundColor: "rgba(255,255,255,0.2)" },
  section: { borderRadius: 16, borderWidth: 1, padding: 16 },
  sectionTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
    letterSpacing: -0.2,
    marginBottom: 12,
  },
  divider: { height: 1, marginBottom: 12 },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 7,
  },
  infoLabel: { fontFamily: "Inter_400Regular", fontSize: 14, flex: 1 },
  infoValue: { fontFamily: "Inter_700Bold", fontSize: 14, letterSpacing: -0.2 },
  partnerCard: { borderRadius: 12, padding: 14 },
  partnerHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 6 },
  partnerName: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
  partnerAmount: { fontFamily: "Inter_700Bold", fontSize: 22, letterSpacing: -0.5, marginBottom: 8 },
  itemsList: { gap: 3 },
  itemText: { fontFamily: "Inter_400Regular", fontSize: 12 },
  dayRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 5 },
  dayName: { fontFamily: "Inter_500Medium", fontSize: 12, width: 40 },
  dayBarWrap: { flex: 1, height: 6, backgroundColor: "#E8E0D4", borderRadius: 3, overflow: "hidden" },
  dayBar: { height: 6, borderRadius: 3 },
  dayAmount: { fontFamily: "Inter_600SemiBold", fontSize: 12, width: 52, textAlign: "right" },
  productRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 6 },
  prodRank: { width: 22, height: 22, borderRadius: 6, alignItems: "center", justifyContent: "center" },
  prodRankText: { fontFamily: "Inter_700Bold", fontSize: 11 },
  prodName: { flex: 1, fontFamily: "Inter_500Medium", fontSize: 13 },
  prodAmount: { fontFamily: "Inter_700Bold", fontSize: 13, letterSpacing: -0.3 },
});
