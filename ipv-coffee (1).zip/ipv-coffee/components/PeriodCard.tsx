import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";
import { formatCurrency } from "@/utils/format";
import type { Periodo } from "@/utils/parseExcel";

interface PeriodCardProps {
  period: Periodo;
  index: number;
}

export function PeriodCard({ period, index }: PeriodCardProps) {
  const colors = useColors();
  const isProfit = period.utilidad_bruta > 0;

  return (
    <Pressable
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          opacity: pressed ? 0.75 : 1,
        },
      ]}
      onPress={() => router.push({ pathname: "/period/[id]", params: { id: String(index) } })}
    >
      <View style={styles.left}>
        <View style={[styles.badge, { backgroundColor: colors.muted }]}>
          <Text style={[styles.badgeText, { color: colors.primary }]}>#{index + 1}</Text>
        </View>
        <View style={styles.textGroup}>
          <Text style={[styles.period, { color: colors.foreground }]}>{period.periodo}</Text>
          <Text style={[styles.sub, { color: colors.mutedForeground }]}>
            Ventas: {formatCurrency(period.ventas)}
          </Text>
        </View>
      </View>
      <View style={styles.right}>
        <Text style={[styles.utilidad, { color: isProfit ? colors.success : colors.destructive }]}>
          {formatCurrency(period.utilidad_bruta)}
        </Text>
        <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginHorizontal: 20,
    marginBottom: 10,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
  },
  left: { flexDirection: "row", alignItems: "center", gap: 12, flex: 1 },
  badge: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  badgeText: { fontFamily: "Inter_700Bold", fontSize: 12 },
  textGroup: { flex: 1, gap: 2 },
  period: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  sub: { fontFamily: "Inter_400Regular", fontSize: 12 },
  right: { flexDirection: "row", alignItems: "center", gap: 6 },
  utilidad: { fontFamily: "Inter_700Bold", fontSize: 15 },
});
