import * as XLSX from "xlsx";

export interface Product {
  producto: string;
  categoria: string;
  precio: number;
  inicio: number;
  ventas_u: number;
  importe: number;
  final: number;
  merma: number;
}

export interface DayVenta {
  dia: string;
  monto: number;
}

export interface PartnerItem {
  item: string;
  qty: number;
}

export interface Periodo {
  periodo: string;
  ventas: number;
  costo: number;
  utilidad_bruta: number;
  utilidad_orly: number;
  utilidad_alejandro: number;
  salario: number;
  faltante: number;
  seguridad: number;
  economico: number;
  efectivo: number;
  inversion: number;
  sobrante: number;
  orly_items: PartnerItem[];
  ale_items: PartnerItem[];
  daily_ventas: DayVenta[];
  products: Product[];
}

function toNum(val: unknown): number {
  const n = Number(val);
  return isNaN(n) ? 0 : n;
}

function toStr(val: unknown): string {
  return val == null ? "" : String(val);
}

function parsePeriodSheet(ws: XLSX.WorkSheet): Omit<Periodo, "periodo"> {
  const data: unknown[][] = XLSX.utils.sheet_to_json(ws, {
    header: 1,
    defval: "",
  }) as unknown[][];

  const row = (i: number): unknown[] => data[i] ?? [];

  const products: Product[] = [];
  for (let i = 38; i < data.length; i++) {
    const r = data[i] ?? [];
    const name = toStr(r[4]);
    if (name) {
      products.push({
        producto: name,
        categoria: toStr(r[3]) || "VENTA",
        precio: toNum(r[16]),
        inicio: toNum(r[6]),
        ventas_u: toNum(r[13]),
        importe: toNum(r[17]),
        final: toNum(r[20]),
        merma: toNum(r[26]),
      });
    }
  }

  const orly_items: PartnerItem[] = [];
  const ale_items: PartnerItem[] = [];
  for (let i = 4; i <= 16; i++) {
    const r = data[i] ?? [];
    const orlyItem = toStr(r[5]);
    const orlyQty = toNum(r[6]);
    if (orlyItem && orlyQty > 0) orly_items.push({ item: orlyItem, qty: orlyQty });
    const aleItem = toStr(r[7]);
    const aleQty = toNum(r[8]);
    if (aleItem && aleQty > 0) ale_items.push({ item: aleItem, qty: aleQty });
  }

  const daily_ventas: DayVenta[] = [];
  for (let i = 6; i <= 13; i++) {
    const r = data[i] ?? [];
    const dia = toStr(r[17]);
    if (dia.startsWith("DIA")) {
      daily_ventas.push({ dia, monto: toNum(r[18]) });
    }
  }

  return {
    ventas: toNum(row(6)[2]),
    costo: toNum(row(21)[2]),
    utilidad_bruta: toNum(row(22)[2]),
    utilidad_orly: toNum(row(23)[3]),
    utilidad_alejandro: toNum(row(24)[3]),
    salario: toNum(row(12)[3]),
    faltante: toNum(row(11)[3]),
    seguridad: toNum(row(16)[2]),
    economico: toNum(row(18)[2]),
    efectivo: toNum(row(25)[2]),
    inversion: toNum(row(26)[2]),
    sobrante: toNum(row(2)[8]),
    orly_items,
    ale_items,
    daily_ventas,
    products: products.slice(0, 120),
  };
}

export function parseWorkbook(base64: string): Periodo[] {
  const wb = XLSX.read(base64, { type: "base64" });
  const periodSheets = wb.SheetNames.filter(
    (name) => !name.startsWith("LISTAS")
  );

  const periods: Periodo[] = [];
  for (const sheetName of periodSheets) {
    try {
      const ws = wb.Sheets[sheetName];
      const parsed = parsePeriodSheet(ws);
      periods.push({ periodo: sheetName, ...parsed });
    } catch {
      // skip malformed sheets
    }
  }
  return periods;
}
