import { Feather } from "@expo/vector-icons";
import React, { useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ImportScreen } from "@/components/ImportScreen";
import { useColors } from "@/hooks/useColors";
import { useData } from "@/contexts/DataContext";
import { formatCurrency, formatCurrencyFull } from "@/utils/format";

export default function InventarioScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { periods, loading } = useData();
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [showPicker, setShowPicker] = useState(false);

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} size="large" />
      </View>
    );
  }

  if (periods.length === 0) return <ImportScreen />;

  const idx = selectedIdx ?? periods.length - 1;
  const period = periods[idx];
  const products = period.products.filter((p) =>
    p.producto.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: insets.top + (Platform.OS === "web" ? 67 : 16),
            backgroundColor: colors.background,
            zIndex: 100,
          },
        ]}
      >
        <Text style={[styles.title, { color: colors.foreground }]}>Inventario</Text>

        <Pressable
          style={({ pressed }) => [
            styles.periodSelector,
            { backgroundColor: colors.muted, borderColor: colors.border, opacity: pressed ? 0.7 : 1 },
          ]}
          onPress={() => setShowPicker(!showPicker)}
        >
          <Feather name="calendar" size={14} color={colors.primary} />
          <Text style={[styles.periodSelectorText, { color: colors.foreground }]}>
            {period.periodo}
          </Text>
          <Feather name={showPicker ? "chevron-up" : "chevron-down"} size={14} color={colors.mutedForeground} />
        </Pressable>

        {showPicker && (
          <View style={[styles.picker, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <ScrollView style={{ maxHeight: 200 }} showsVerticalScrollIndicator={false}>
              {[...periods].reverse().map((p, ri) => {
                const actualIdx = periods.length - 1 - ri;
                return (
                  <Pressable
                    key={p.periodo}
                    style={({ pressed }) => [
                      styles.pickerItem,
                      {
                        backgroundColor:
                          actualIdx === idx ? colors.muted : pressed ? colors.muted : "transparent",
                      },
                    ]}
                    onPress={() => {
                      setSelectedIdx(actualIdx);
                      setShowPicker(false);
                    }}
                  >
                    <Text
                      style={[
                        styles.pickerItemText,
                        {
                          color: actualIdx === idx ? colors.primary : colors.foreground,
                          fontFamily: actualIdx === idx ? "Inter_600SemiBold" : "Inter_400Regular",
                        },
                      ]}
                    >
                      {p.periodo}
                    </Text>
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>
        )}

        <View style={[styles.searchBox, { backgroundColor: colors.muted, borderColor: colors.border }]}>
          <Feather name="search" size={16} color={colors.mutedForeground} />
          <TextInput
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="Buscar producto..."
            placeholderTextColor={colors.mutedForeground}
            value={search}
            onChangeText={setSearch}
          />
        </View>

        <View style={styles.summaryRow}>
          <View style={[styles.summaryChip, { backgroundColor: colors.muted }]}>
            <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Productos</Text>
            <Text style={[styles.summaryValue, { color: colors.foreground }]}>{period.products.length}</Text>
          </View>
          <View style={[styles.summaryChip, { backgroundColor: colors.muted }]}>
            <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Ventas</Text>
            <Text style={[styles.summaryValue, { color: colors.primary }]}>{formatCurrency(period.ventas)}</Text>
          </View>
          <View style={[styles.summaryChip, { backgroundColor: colors.muted }]}>
            <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Utilidad</Text>
            <Text style={[styles.summaryValue, { color: colors.success }]}>{formatCurrency(period.utilidad_bruta)}</Text>
          </View>
        </View>
      </View>

      <FlatList
        data={products}
        keyExtractor={(item, i) => `${item.producto}-${i}`}
        renderItem={({ item }) => (
          <View style={[styles.productRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.productLeft}>
              <View style={[styles.catDot, { backgroundColor: item.importe > 0 ? colors.success : colors.muted }]} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.productName, { color: colors.foreground }]} numberOfLines={1}>
                  {item.producto}
                </Text>
                <Text style={[styles.productCat, { color: colors.mutedForeground }]}>
                  {item.categoria} · Precio: {formatCurrencyFull(item.precio)}
                </Text>
              </View>
            </View>
            <View style={styles.productRight}>
              <Text style={[styles.productImporte, { color: item.importe > 0 ? colors.foreground : colors.mutedForeground }]}>
                {formatCurrency(item.importe)}
              </Text>
              <Text style={[styles.productFinal, { color: colors.mutedForeground }]}>
                Final: {item.final}
              </Text>
            </View>
          </View>
        )}
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 100) },
        ]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="package" size={28} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              No se encontraron productos
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  header: { paddingHorizontal: 20, paddingBottom: 12 },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 28,
    letterSpacing: -0.5,
    marginBottom: 12,
  },
  periodSelector: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 9,
    gap: 8,
    marginBottom: 10,
  },
  periodSelectorText: {
    flex: 1,
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
  picker: {
    position: "absolute",
    top: 115,
    left: 20,
    right: 20,
    borderRadius: 12,
    borderWidth: 1,
    zIndex: 200,
    elevation: 10,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  pickerItem: { paddingHorizontal: 16, paddingVertical: 11 },
  pickerItemText: { fontSize: 14 },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 8,
    marginBottom: 12,
  },
  searchInput: {
    flex: 1,
    fontFamily: "Inter_400Regular",
    fontSize: 15,
  },
  summaryRow: { flexDirection: "row", gap: 8 },
  summaryChip: {
    flex: 1,
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
  },
  summaryLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 10,
    textTransform: "uppercase",
    letterSpacing: 0.3,
  },
  summaryValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 14,
    marginTop: 2,
    letterSpacing: -0.3,
  },
  listContent: { paddingTop: 8, paddingHorizontal: 20 },
  productRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    marginBottom: 8,
  },
  productLeft: { flex: 1, flexDirection: "row", alignItems: "center", gap: 10 },
  catDot: { width: 8, height: 8, borderRadius: 4 },
  productName: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  productCat: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 2 },
  productRight: { alignItems: "flex-end", gap: 2 },
  productImporte: { fontFamily: "Inter_700Bold", fontSize: 14, letterSpacing: -0.3 },
  productFinal: { fontFamily: "Inter_400Regular", fontSize: 11 },
  empty: { alignItems: "center", paddingTop: 40, gap: 10 },
  emptyText: { fontFamily: "Inter_400Regular", fontSize: 14 },
});
