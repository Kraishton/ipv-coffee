import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatCard } from "@/components/StatCard";
import { ImportScreen } from "@/components/ImportScreen";
import { useColors } from "@/hooks/useColors";
import { useData } from "@/contexts/DataContext";
import { formatCurrency, formatCurrencyFull, formatPercent } from "@/utils/format";

export default function DashboardScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { periods, meta, loading, importFile, importing } = useData();

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} size="large" />
      </View>
    );
  }

  if (periods.length === 0) {
    return <ImportScreen />;
  }

  const latest = periods[periods.length - 1];
  const prev = periods[periods.length - 2] ?? latest;

  const totalVentasAll = periods.reduce((s, p) => s + p.ventas, 0);
  const totalUtilidadAll = periods.reduce((s, p) => s + p.utilidad_bruta, 0);
  const totalOrlyAll = periods.reduce((s, p) => s + p.utilidad_orly, 0);
  const totalAleAll = periods.reduce((s, p) => s + p.utilidad_alejandro, 0);

  const ventasDiff = latest.ventas - prev.ventas;
  const utilDiff = latest.utilidad_bruta - prev.utilidad_bruta;
  const margen = formatPercent(latest.utilidad_bruta, latest.ventas);
  const topVentasPeriod = [...periods].sort((a, b) => b.ventas - a.ventas)[0];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: insets.top + (Platform.OS === "web" ? 67 : 16),
          paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 100),
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.brand, { color: colors.primary }]}>IPV Coffee Bar</Text>
          <Text style={[styles.headerSub, { color: colors.mutedForeground }]} numberOfLines={1}>
            {meta?.fileName ?? "Dashboard General"}
          </Text>
        </View>
        <Pressable
          style={({ pressed }) => [
            styles.iconBg,
            { backgroundColor: colors.muted, opacity: pressed ? 0.7 : 1 },
          ]}
          onPress={importFile}
          disabled={importing}
        >
          {importing ? (
            <ActivityIndicator size="small" color={colors.primary} />
          ) : (
            <Feather name="upload-cloud" size={20} color={colors.primary} />
          )}
        </Pressable>
      </View>

      {/* Latest Period Banner */}
      <Pressable
        style={({ pressed }) => [
          styles.banner,
          { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
        ]}
        onPress={() =>
          router.push({ pathname: "/period/[id]", params: { id: String(periods.length - 1) } })
        }
      >
        <View style={{ flex: 1 }}>
          <Text style={styles.bannerLabel}>Último Período</Text>
          <Text style={styles.bannerPeriod}>{latest.periodo}</Text>
          <Text style={styles.bannerVentas}>{formatCurrencyFull(latest.ventas)}</Text>
          <Text style={styles.bannerSub}>Ventas totales</Text>
        </View>
        <View style={styles.bannerRight}>
          <View style={styles.bannerStat}>
            <Text style={styles.bannerStatLabel}>Utilidad</Text>
            <Text style={styles.bannerStatValue}>{formatCurrency(latest.utilidad_bruta)}</Text>
          </View>
          <View style={styles.bannerStat}>
            <Text style={styles.bannerStatLabel}>Margen</Text>
            <Text style={styles.bannerStatValue}>{margen}</Text>
          </View>
          <Feather name="arrow-right" size={20} color="rgba(255,255,255,0.7)" style={{ marginTop: 8 }} />
        </View>
      </Pressable>

      {/* Current Period Stats */}
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Período Actual</Text>
      <View style={styles.statsRow}>
        <StatCard
          label="Costo"
          value={formatCurrency(latest.costo)}
          sub={formatPercent(latest.costo, latest.ventas) + " de ventas"}
          color={colors.destructive}
        />
        <StatCard
          label="Inversión"
          value={formatCurrency(latest.inversion)}
          sub="Restante"
          color={colors.accent}
        />
      </View>
      <View style={styles.statsRow}>
        <StatCard label="Util. Orly" value={formatCurrency(latest.utilidad_orly)} color={colors.success} />
        <StatCard label="Util. Alejandro" value={formatCurrency(latest.utilidad_alejandro)} color={colors.success} />
      </View>
      <View style={styles.statsRow}>
        <StatCard label="Salario" value={formatCurrency(latest.salario)} />
        <StatCard
          label={latest.sobrante >= 0 ? "Sobrante" : "Faltante"}
          value={formatCurrency(Math.abs(latest.sobrante))}
          color={latest.sobrante >= 0 ? colors.success : colors.destructive}
        />
      </View>

      {/* vs Previous */}
      {periods.length > 1 && (
        <>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>vs Período Anterior</Text>
          <View style={styles.statsRow}>
            <StatCard
              label="Δ Ventas"
              value={formatCurrency(ventasDiff)}
              sub={prev.periodo}
              color={ventasDiff >= 0 ? colors.success : colors.destructive}
            />
            <StatCard
              label="Δ Utilidad"
              value={formatCurrency(utilDiff)}
              sub={prev.periodo}
              color={utilDiff >= 0 ? colors.success : colors.destructive}
            />
          </View>
        </>
      )}

      {/* Historical Totals */}
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Histórico Total</Text>
      <View style={[styles.historicCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.historicRow}>
          <Text style={[styles.historicLabel, { color: colors.mutedForeground }]}>Períodos analizados</Text>
          <Text style={[styles.historicValue, { color: colors.foreground }]}>{periods.length}</Text>
        </View>
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <View style={styles.historicRow}>
          <Text style={[styles.historicLabel, { color: colors.mutedForeground }]}>Ventas acumuladas</Text>
          <Text style={[styles.historicValue, { color: colors.foreground }]}>{formatCurrencyFull(totalVentasAll)}</Text>
        </View>
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <View style={styles.historicRow}>
          <Text style={[styles.historicLabel, { color: colors.mutedForeground }]}>Utilidad bruta total</Text>
          <Text style={[styles.historicValue, { color: colors.success }]}>{formatCurrencyFull(totalUtilidadAll)}</Text>
        </View>
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <View style={styles.historicRow}>
          <Text style={[styles.historicLabel, { color: colors.mutedForeground }]}>Total Orly</Text>
          <Text style={[styles.historicValue, { color: colors.primary }]}>{formatCurrencyFull(totalOrlyAll)}</Text>
        </View>
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <View style={styles.historicRow}>
          <Text style={[styles.historicLabel, { color: colors.mutedForeground }]}>Total Alejandro</Text>
          <Text style={[styles.historicValue, { color: colors.primary }]}>{formatCurrencyFull(totalAleAll)}</Text>
        </View>
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <View style={styles.historicRow}>
          <Text style={[styles.historicLabel, { color: colors.mutedForeground }]}>Mejor período</Text>
          <Text style={[styles.historicValue, { color: colors.accent }]}>{topVentasPeriod.periodo}</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  content: { paddingHorizontal: 20, gap: 0 },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  brand: {
    fontFamily: "Inter_700Bold",
    fontSize: 24,
    letterSpacing: -0.5,
  },
  headerSub: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 2,
  },
  iconBg: {
    width: 42,
    height: 42,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  banner: {
    borderRadius: 18,
    padding: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 24,
  },
  bannerLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 11,
    color: "rgba(255,255,255,0.7)",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: 4,
  },
  bannerPeriod: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
    color: "rgba(255,255,255,0.85)",
    marginBottom: 8,
  },
  bannerVentas: {
    fontFamily: "Inter_700Bold",
    fontSize: 32,
    color: "#FFFFFF",
    letterSpacing: -1,
  },
  bannerSub: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    color: "rgba(255,255,255,0.6)",
    marginTop: 2,
  },
  bannerRight: {
    alignItems: "flex-end",
    justifyContent: "center",
    gap: 12,
  },
  bannerStat: { alignItems: "flex-end" },
  bannerStatLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 11,
    color: "rgba(255,255,255,0.65)",
  },
  bannerStatValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 17,
    color: "#FFFFFF",
    letterSpacing: -0.3,
  },
  sectionTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 17,
    letterSpacing: -0.3,
    marginBottom: 12,
    marginTop: 8,
  },
  statsRow: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 10,
  },
  historicCard: {
    borderRadius: 16,
    borderWidth: 1,
    overflow: "hidden",
    marginTop: 4,
  },
  historicRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  historicLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
  },
  historicValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
    letterSpacing: -0.3,
  },
  divider: { height: 1 },
});
