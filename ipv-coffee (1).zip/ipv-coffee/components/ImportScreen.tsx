import { Feather } from "@expo/vector-icons";
import React from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useData } from "@/contexts/DataContext";

export function ImportScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { importFile, importing, error } = useData();

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: colors.background,
          paddingTop: insets.top + (Platform.OS === "web" ? 67 : 0),
          paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 0),
        },
      ]}
    >
      <View style={styles.inner}>
        {/* Icon */}
        <View style={[styles.iconRing, { borderColor: colors.primary + "33" }]}>
          <View style={[styles.iconBg, { backgroundColor: colors.primary + "22" }]}>
            <Feather name="file-text" size={40} color={colors.primary} />
          </View>
        </View>

        <Text style={[styles.title, { color: colors.foreground }]}>
          IPV Coffee Bar
        </Text>
        <Text style={[styles.subtitle, { color: colors.primary }]}>
          Gestión de Negocio
        </Text>

        <Text style={[styles.description, { color: colors.mutedForeground }]}>
          Importa tu archivo Excel para visualizar los períodos, inventario,
          utilidades y el resumen financiero de tu negocio.
        </Text>

        {/* Supported formats */}
        <View style={[styles.formatsRow, { backgroundColor: colors.muted }]}>
          {[".xlsx", ".xlsm", ".xls"].map((fmt) => (
            <View
              key={fmt}
              style={[styles.fmtBadge, { backgroundColor: colors.card, borderColor: colors.border }]}
            >
              <Text style={[styles.fmtText, { color: colors.foreground }]}>{fmt}</Text>
            </View>
          ))}
        </View>

        {/* Error */}
        {error ? (
          <View style={[styles.errorBox, { backgroundColor: colors.destructive + "15", borderColor: colors.destructive + "40" }]}>
            <Feather name="alert-circle" size={14} color={colors.destructive} />
            <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
          </View>
        ) : null}

        {/* Import Button */}
        <Pressable
          style={({ pressed }) => [
            styles.importBtn,
            { backgroundColor: colors.primary, opacity: pressed || importing ? 0.8 : 1 },
          ]}
          onPress={importFile}
          disabled={importing}
        >
          {importing ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <Feather name="upload" size={20} color="#fff" />
          )}
          <Text style={styles.importBtnText}>
            {importing ? "Procesando..." : "Seleccionar Archivo Excel"}
          </Text>
        </Pressable>

        {/* Structure hint */}
        <View style={[styles.hintBox, { borderColor: colors.border, backgroundColor: colors.card }]}>
          <Text style={[styles.hintTitle, { color: colors.foreground }]}>
            Estructura esperada
          </Text>
          <Text style={[styles.hintText, { color: colors.mutedForeground }]}>
            Cada hoja del Excel representa un período. Las hojas deben contener
            filas de resumen financiero (ventas, costo, utilidad) y un listado
            de productos a partir de la fila 38. Las hojas llamadas "LISTAS" se
            omiten automáticamente.
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
  },
  inner: {
    paddingHorizontal: 32,
    alignItems: "center",
    gap: 16,
  },
  iconRing: {
    width: 110,
    height: 110,
    borderRadius: 55,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  iconBg: {
    width: 82,
    height: 82,
    borderRadius: 41,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 26,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontFamily: "Inter_500Medium",
    fontSize: 14,
    marginTop: -8,
  },
  description: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    textAlign: "center",
    lineHeight: 21,
    marginTop: 4,
  },
  formatsRow: {
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    marginTop: -4,
  },
  fmtBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
  },
  fmtText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  errorBox: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
    alignSelf: "stretch",
  },
  errorText: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    flex: 1,
    lineHeight: 19,
  },
  importBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingVertical: 16,
    paddingHorizontal: 28,
    borderRadius: 16,
    alignSelf: "stretch",
  },
  importBtnText: {
    fontFamily: "Inter_700Bold",
    fontSize: 16,
    color: "#FFFFFF",
  },
  hintBox: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    alignSelf: "stretch",
    gap: 6,
  },
  hintTitle: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  hintText: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    lineHeight: 18,
  },
});
