import { Feather } from "@expo/vector-icons";
import React from "react";
import {
  ActivityIndicator,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ImportScreen } from "@/components/ImportScreen";
import { useColors } from "@/hooks/useColors";
import { useData } from "@/contexts/DataContext";
import { formatCurrencyFull, formatPercent } from "@/utils/format";

function Row({ label, value, color, bold }: { label: string; value: string; color?: string; bold?: boolean }) {
  const colors = useColors();
  return (
    <View style={styles.row}>
      <Text style={[styles.rowLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.rowValue, { color: color ?? colors.foreground, fontFamily: bold ? "Inter_700Bold" : "Inter_600SemiBold" }]}>
        {value}
      </Text>
    </View>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  const colors = useColors();
  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Text style={[styles.cardTitle, { color: colors.foreground }]}>{title}</Text>
      <View style={[styles.divider, { backgroundColor: colors.border }]} />
      {children}
    </View>
  );
}

export default function ResumenScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { periods, loading } = useData();

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} size="large" />
      </View>
    );
  }

  if (periods.length === 0) return <ImportScreen />;

  const totalVentas = periods.reduce((s, p) => s + p.ventas, 0);
  const totalCosto = periods.reduce((s, p) => s + p.costo, 0);
  const totalUtilidad = periods.reduce((s, p) => s + p.utilidad_bruta, 0);
  const totalOrly = periods.reduce((s, p) => s + p.utilidad_orly, 0);
  const totalAle = periods.reduce((s, p) => s + p.utilidad_alejandro, 0);
  const totalSalario = periods.reduce((s, p) => s + p.salario, 0);
  const totalSeguridad = periods.reduce((s, p) => s + p.seguridad, 0);
  const totalEconomico = periods.reduce((s, p) => s + p.economico, 0);

  const promedioVentas = totalVentas / periods.length;
  const promedioUtilidad = totalUtilidad / periods.length;
  const margenTotal = formatPercent(totalUtilidad, totalVentas);

  const sortedByVentas = [...periods].sort((a, b) => b.ventas - a.ventas);
  const sortedByUtil = [...periods].sort((a, b) => b.utilidad_bruta - a.utilidad_bruta);
  const top5Ventas = sortedByVentas.slice(0, 5);
  const worst3 = sortedByVentas.slice(-3).reverse();

  const periodosSobrante = periods.filter((p) => p.sobrante > 0).length;
  const periodosFaltante = periods.filter((p) => p.sobrante < 0).length;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: insets.top + (Platform.OS === "web" ? 67 : 16),
          paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 100),
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <Text style={[styles.title, { color: colors.foreground }]}>Resumen</Text>
      <Text style={[styles.sub, { color: colors.mutedForeground }]}>
        {periods.length} períodos · {periods[0].periodo} → {periods[periods.length - 1].periodo}
      </Text>

      <Card title="Totales Acumulados">
        <Row label="Ventas totales" value={formatCurrencyFull(totalVentas)} color={colors.foreground} bold />
        <Row label="Costo total" value={formatCurrencyFull(totalCosto)} color={colors.destructive} />
        <Row label="Utilidad bruta" value={formatCurrencyFull(totalUtilidad)} color={colors.success} bold />
        <Row label="Margen total" value={margenTotal} color={colors.accent} />
        <Row label="Total Orly" value={formatCurrencyFull(totalOrly)} color={colors.primary} />
        <Row label="Total Alejandro" value={formatCurrencyFull(totalAle)} color={colors.primary} />
        <Row label="Salarios pagados" value={formatCurrencyFull(totalSalario)} />
        <Row label="Seguridad" value={formatCurrencyFull(totalSeguridad)} />
        <Row label="Económico" value={formatCurrencyFull(totalEconomico)} />
      </Card>

      <Card title="Promedios por Período">
        <Row label="Ventas promedio" value={formatCurrencyFull(promedioVentas)} />
        <Row label="Utilidad promedio" value={formatCurrencyFull(promedioUtilidad)} color={colors.success} />
        <Row label="Margen promedio" value={margenTotal} />
        <Row label="Períodos con sobrante" value={`${periodosSobrante} de ${periods.length}`} color={colors.success} />
        <Row label="Períodos con faltante" value={`${periodosFaltante} de ${periods.length}`} color={colors.destructive} />
      </Card>

      <Card title="Top 5 Períodos — Ventas">
        {top5Ventas.map((p, i) => (
          <View key={p.periodo} style={styles.topRow}>
            <View style={[styles.rank, { backgroundColor: i === 0 ? colors.primary : colors.muted }]}>
              <Text style={[styles.rankText, { color: i === 0 ? "#fff" : colors.mutedForeground }]}>{i + 1}</Text>
            </View>
            <Text style={[styles.topPeriod, { color: colors.foreground }]} numberOfLines={1}>{p.periodo}</Text>
            <Text style={[styles.topValue, { color: colors.foreground }]}>{formatCurrencyFull(p.ventas)}</Text>
          </View>
        ))}
      </Card>

      <Card title="Top 5 Períodos — Utilidad">
        {sortedByUtil.slice(0, 5).map((p, i) => (
          <View key={p.periodo} style={styles.topRow}>
            <View style={[styles.rank, { backgroundColor: i === 0 ? colors.success : colors.muted }]}>
              <Text style={[styles.rankText, { color: i === 0 ? "#fff" : colors.mutedForeground }]}>{i + 1}</Text>
            </View>
            <Text style={[styles.topPeriod, { color: colors.foreground }]} numberOfLines={1}>{p.periodo}</Text>
            <Text style={[styles.topValue, { color: colors.success }]}>{formatCurrencyFull(p.utilidad_bruta)}</Text>
          </View>
        ))}
      </Card>

      <Card title="Menores Ventas">
        {worst3.map((p, i) => (
          <View key={p.periodo} style={styles.topRow}>
            <Feather name="trending-down" size={16} color={colors.destructive} />
            <Text style={[styles.topPeriod, { color: colors.foreground }]} numberOfLines={1}>{p.periodo}</Text>
            <Text style={[styles.topValue, { color: colors.destructive }]}>{formatCurrencyFull(p.ventas)}</Text>
          </View>
        ))}
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  content: { paddingHorizontal: 20, gap: 16 },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 28,
    letterSpacing: -0.5,
    marginBottom: 2,
  },
  sub: { fontFamily: "Inter_400Regular", fontSize: 13 },
  card: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
  },
  cardTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
    letterSpacing: -0.2,
    marginBottom: 12,
  },
  divider: { height: 1, marginBottom: 12 },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 7,
  },
  rowLabel: { fontFamily: "Inter_400Regular", fontSize: 14, flex: 1 },
  rowValue: { fontSize: 14, letterSpacing: -0.2 },
  topRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 6,
  },
  rank: {
    width: 24,
    height: 24,
    borderRadius: 7,
    alignItems: "center",
    justifyContent: "center",
  },
  rankText: { fontFamily: "Inter_700Bold", fontSize: 11 },
  topPeriod: { fontFamily: "Inter_500Medium", fontSize: 13, flex: 1 },
  topValue: { fontFamily: "Inter_700Bold", fontSize: 13, letterSpacing: -0.3 },
});
