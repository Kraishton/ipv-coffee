export function formatCurrency(value: number): string {
  if (value === 0) return "$0";
  const abs = Math.abs(value);
  let formatted: string;
  if (abs >= 1_000_000) {
    formatted = (abs / 1_000_000).toFixed(1) + "M";
  } else if (abs >= 1_000) {
    formatted = (abs / 1_000).toFixed(1) + "K";
  } else {
    formatted = abs.toLocaleString("es-CU");
  }
  return value < 0 ? `-$${formatted}` : `$${formatted}`;
}

export function formatCurrencyFull(value: number): string {
  return "$" + Math.abs(value).toLocaleString("es-CU", { maximumFractionDigits: 0 });
}

export function formatPercent(value: number, total: number): string {
  if (total === 0) return "0%";
  return ((value / total) * 100).toFixed(1) + "%";
}
