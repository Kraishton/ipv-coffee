import AsyncStorage from "@react-native-async-storage/async-storage";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { Platform } from "react-native";
import type { Periodo } from "@/utils/parseExcel";
import { parseWorkbook } from "@/utils/parseExcel";

const STORAGE_KEY = "@ipv_coffee_periods_v2";
const META_KEY = "@ipv_coffee_meta_v2";

interface DataMeta {
  fileName: string;
  importedAt: string;
  periodCount: number;
}

interface DataContextValue {
  periods: Periodo[];
  meta: DataMeta | null;
  loading: boolean;
  importing: boolean;
  error: string | null;
  importFile: () => Promise<void>;
  clearData: () => Promise<void>;
}

const DataContext = createContext<DataContextValue>({
  periods: [],
  meta: null,
  loading: true,
  importing: false,
  error: null,
  importFile: async () => {},
  clearData: async () => {},
});

async function readFileAsBase64(uri: string): Promise<string> {
  if (Platform.OS === "web") {
    // On web, the URI is a blob URL — use fetch + FileReader
    const response = await fetch(uri);
    const blob = await response.blob();
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        // result is "data:<mime>;base64,<data>" — strip the prefix
        const base64 = result.split(",")[1];
        if (base64) resolve(base64);
        else reject(new Error("FileReader returned empty result"));
      };
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
  } else {
    // On native, use expo-file-system
    return FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
    });
  }
}

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [periods, setPeriods] = useState<Periodo[]>([]);
  const [meta, setMeta] = useState<DataMeta | null>(null);
  const [loading, setLoading] = useState(true);
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [stored, storedMeta] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEY),
          AsyncStorage.getItem(META_KEY),
        ]);
        if (stored) setPeriods(JSON.parse(stored) as Periodo[]);
        if (storedMeta) setMeta(JSON.parse(storedMeta) as DataMeta);
      } catch {
        // ignore storage errors on first launch
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const importFile = useCallback(async () => {
    setError(null);
    setImporting(true);
    try {
      // Use "*/*" to allow all files — filtering by MIME type is unreliable
      // across Android versions and web browsers for Excel files
      const result = await DocumentPicker.getDocumentAsync({
        type: "*/*",
        copyToCacheDirectory: true,
      });

      if (result.canceled || !result.assets?.[0]) {
        setImporting(false);
        return;
      }

      const asset = result.assets[0];
      const uri = asset.uri;
      const fileName = asset.name ?? "archivo.xlsx";

      // Validate extension
      const lower = fileName.toLowerCase();
      const validExt = lower.endsWith(".xlsx") || lower.endsWith(".xlsm") || lower.endsWith(".xls");
      if (!validExt) {
        setError(`Archivo no reconocido: "${fileName}". Selecciona un archivo Excel (.xlsx, .xlsm o .xls).`);
        setImporting(false);
        return;
      }

      const base64 = await readFileAsBase64(uri);
      const parsed = parseWorkbook(base64);

      if (parsed.length === 0) {
        setError(
          "No se encontraron períodos en el archivo. Verifica que cada hoja represente un período y que no esté vacía."
        );
        setImporting(false);
        return;
      }

      const newMeta: DataMeta = {
        fileName,
        importedAt: new Date().toISOString(),
        periodCount: parsed.length,
      };

      await Promise.all([
        AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(parsed)),
        AsyncStorage.setItem(META_KEY, JSON.stringify(newMeta)),
      ]);

      setPeriods(parsed);
      setMeta(newMeta);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      setError(`Error al leer el archivo: ${msg}`);
    } finally {
      setImporting(false);
    }
  }, []);

  const clearData = useCallback(async () => {
    await Promise.all([
      AsyncStorage.removeItem(STORAGE_KEY),
      AsyncStorage.removeItem(META_KEY),
    ]);
    setPeriods([]);
    setMeta(null);
  }, []);

  return (
    <DataContext.Provider
      value={{ periods, meta, loading, importing, error, importFile, clearData }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  return useContext(DataContext);
}
