import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React, { useMemo } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useData } from "@/contexts/DataContext";
import { formatCurrency, formatCurrencyFull, formatPercent } from "@/utils/format";

export default function ProductDetail() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { name } = useLocalSearchParams<{ name: string }>();
  const { periods } = useData();

  const productName = decodeURIComponent(name ?? "");

  const stats = useMemo(() => {
    // Build per-period data for this product
    const perPeriod = periods.map((period) => {
      const found = period.products.find(
        (p) => p.producto.toLowerCase() === productName.toLowerCase()
      );
      return {
        periodo: period.periodo,
        importe: found?.importe ?? 0,
        ventas_u: found?.ventas_u ?? 0,
        precio: found?.precio ?? 0,
        appeared: !!found,
      };
    });

    const appeared = perPeriod.filter((p) => p.appeared);
    const totalImporte = appeared.reduce((s, p) => s + p.importe, 0);
    const totalVentasU = appeared.reduce((s, p) => s + p.ventas_u, 0);
    const avgImporte = appeared.length > 0 ? totalImporte / appeared.length : 0;
    const bestPeriod = appeared.reduce(
      (best, p) => (p.importe > (best?.importe ?? 0) ? p : best),
      appeared[0]
    );

    // Total ventas de todos los períodos para calcular porcentaje
    const totalVentasNegocio = periods.reduce((s, p) => s + p.ventas, 0);
    const porcentajeNegocio = totalVentasNegocio > 0 ? (totalImporte / totalVentasNegocio) * 100 : 0;

    // Top 6 productos por importe total (para comparación)
    const productMap: Record<string, number> = {};
    periods.forEach((period) => {
      period.products.forEach((p) => {
        if (!productMap[p.producto]) productMap[p.producto] = 0;
        productMap[p.producto] += p.importe;
      });
    });
    const topProducts = Object.entries(productMap)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6);
    const maxComparison = topProducts[0]?.[1] ?? 1;

    return {
      perPeriod,
      appeared,
      totalImporte,
      totalVentasU,
      avgImporte,
      bestPeriod,
      porcentajeNegocio,
      topProducts,
      maxComparison,
    };
  }, [periods, productName]);

  const maxBarImporte = Math.max(...stats.appeared.map((p) => p.importe), 1);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Nav */}
      <View
        style={[
          styles.navBar,
          {
            paddingTop: insets.top + (Platform.OS === "web" ? 67 : 8),
            backgroundColor: colors.background,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [styles.backBtn, { opacity: pressed ? 0.6 : 1 }]}
        >
          <Feather name="arrow-left" size={22} color={colors.primary} />
        </Pressable>
        <Text style={[styles.navTitle, { color: colors.foreground }]} numberOfLines={1}>
          {productName}
        </Text>
        <View style={{ width: 36 }} />
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 40) },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero totales */}
        <View style={[styles.hero, { backgroundColor: colors.primary }]}>
          <Text style={styles.heroLabel}>Importe total acumulado</Text>
          <Text style={styles.heroAmount}>{formatCurrencyFull(stats.totalImporte)}</Text>
          <View style={styles.heroRow}>
            <View style={styles.heroStat}>
              <Text style={styles.heroStatLabel}>Períodos</Text>
              <Text style={styles.heroStatValue}>{stats.appeared.length}</Text>
            </View>
            <View style={styles.heroDivider} />
            <View style={styles.heroStat}>
              <Text style={styles.heroStatLabel}>Promedio/período</Text>
              <Text style={styles.heroStatValue}>{formatCurrency(stats.avgImporte)}</Text>
            </View>
            <View style={styles.heroDivider} />
            <View style={styles.heroStat}>
              <Text style={styles.heroStatLabel}>% del negocio</Text>
              <Text style={styles.heroStatValue}>{stats.porcentajeNegocio.toFixed(1)}%</Text>
            </View>
          </View>
        </View>

        {/* Resumen rápido */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Resumen</Text>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />

          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Mejor período</Text>
            <View style={styles.infoRight}>
              <Text style={[styles.infoValue, { color: colors.primary }]}>
                {stats.bestPeriod?.periodo ?? "—"}
              </Text>
              {stats.bestPeriod && (
                <Text style={[styles.infoSub, { color: colors.mutedForeground }]}>
                  {formatCurrencyFull(stats.bestPeriod.importe)}
                </Text>
              )}
            </View>
          </View>

          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Unidades vendidas</Text>
            <Text style={[styles.infoValue, { color: colors.foreground }]}>
              {stats.totalVentasU.toLocaleString("es-CU")}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Precio unitario</Text>
            <Text style={[styles.infoValue, { color: colors.foreground }]}>
              {stats.appeared[0]?.precio
                ? formatCurrencyFull(stats.appeared[stats.appeared.length - 1].precio)
                : "—"}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Períodos sin venta</Text>
            <Text style={[styles.infoValue, { color: colors.mutedForeground }]}>
              {periods.length - stats.appeared.length}
            </Text>
          </View>
        </View>

        {/* Importe por período — barra horizontal */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            Importe por Período
          </Text>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />

          {stats.perPeriod.length === 0 ? (
            <Text style={[styles.empty, { color: colors.mutedForeground }]}>Sin datos</Text>
          ) : (
            [...stats.perPeriod].reverse().map((p, i) => (
              <View key={i} style={styles.barRow}>
                <Text
                  style={[
                    styles.barLabel,
                    { color: p.appeared ? colors.foreground : colors.mutedForeground },
                  ]}
                  numberOfLines={1}
                >
                  {p.periodo}
                </Text>
                <View style={styles.barTrack}>
                  <View
                    style={[
                      styles.barFill,
                      {
                        backgroundColor: p.appeared ? colors.primary : colors.border,
                        width: p.importe > 0
                          ? `${Math.max(2, (p.importe / maxBarImporte) * 100)}%`
                          : "2%",
                      },
                    ]}
                  />
                </View>
                <Text
                  style={[
                    styles.barAmount,
                    { color: p.appeared ? colors.foreground : colors.mutedForeground },
                  ]}
                >
                  {p.importe > 0 ? formatCurrency(p.importe) : "—"}
                </Text>
              </View>
            ))
          )}
        </View>

        {/* Comparación con otros top productos */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            vs Otros Productos (total acumulado)
          </Text>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />

          {stats.topProducts.map(([prod, total], i) => {
            const isThis = prod.toLowerCase() === productName.toLowerCase();
            return (
              <View key={i} style={styles.cmpRow}>
                <View style={styles.cmpLeft}>
                  {isThis ? (
                    <View style={[styles.cmpDot, { backgroundColor: colors.primary }]} />
                  ) : (
                    <Text style={[styles.cmpRank, { color: colors.mutedForeground }]}>{i + 1}</Text>
                  )}
                  <Text
                    style={[
                      styles.cmpName,
                      {
                        color: isThis ? colors.primary : colors.foreground,
                        fontFamily: isThis ? "Inter_700Bold" : "Inter_500Medium",
                      },
                    ]}
                    numberOfLines={1}
                  >
                    {isThis ? `★ ${prod}` : prod}
                  </Text>
                </View>
                <View style={styles.cmpBarWrap}>
                  <View
                    style={[
                      styles.cmpBar,
                      {
                        backgroundColor: isThis ? colors.primary : colors.muted,
                        width: `${Math.max(3, (total / stats.maxComparison) * 100)}%`,
                        borderColor: isThis ? colors.primary : colors.border,
                      },
                    ]}
                  />
                </View>
                <Text
                  style={[
                    styles.cmpAmount,
                    { color: isThis ? colors.primary : colors.foreground },
                  ]}
                >
                  {formatCurrency(total)}
                </Text>
              </View>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  navBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    gap: 8,
  },
  backBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  navTitle: {
    flex: 1,
    fontFamily: "Inter_700Bold",
    fontSize: 17,
    textAlign: "center",
    letterSpacing: -0.3,
  },
  content: { padding: 20, gap: 16 },

  hero: { borderRadius: 18, padding: 20 },
  heroLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 11,
    color: "rgba(255,255,255,0.7)",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: 6,
  },
  heroAmount: {
    fontFamily: "Inter_700Bold",
    fontSize: 36,
    color: "#fff",
    letterSpacing: -1,
    marginBottom: 16,
  },
  heroRow: { flexDirection: "row", alignItems: "center" },
  heroStat: { flex: 1, alignItems: "center" },
  heroStatLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 11,
    color: "rgba(255,255,255,0.65)",
    marginBottom: 4,
    textAlign: "center",
  },
  heroStatValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 15,
    color: "#fff",
    letterSpacing: -0.3,
  },
  heroDivider: { width: 1, height: 32, backgroundColor: "rgba(255,255,255,0.2)" },

  section: { borderRadius: 16, borderWidth: 1, padding: 16 },
  sectionTitle: { fontFamily: "Inter_700Bold", fontSize: 15, letterSpacing: -0.2, marginBottom: 12 },
  divider: { height: 1, marginBottom: 12 },
  empty: { fontFamily: "Inter_400Regular", fontSize: 14, textAlign: "center", paddingVertical: 12 },

  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 8,
  },
  infoLabel: { fontFamily: "Inter_400Regular", fontSize: 14, flex: 1 },
  infoRight: { alignItems: "flex-end" },
  infoValue: { fontFamily: "Inter_700Bold", fontSize: 14, letterSpacing: -0.2 },
  infoSub: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 1 },

  barRow: { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 4 },
  barLabel: { fontFamily: "Inter_500Medium", fontSize: 11, width: 76 },
  barTrack: {
    flex: 1,
    height: 8,
    backgroundColor: "#E8E0D4",
    borderRadius: 4,
    overflow: "hidden",
  },
  barFill: { height: 8, borderRadius: 4 },
  barAmount: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
    width: 50,
    textAlign: "right",
  },

  cmpRow: { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 5 },
  cmpLeft: { flexDirection: "row", alignItems: "center", gap: 6, width: 130 },
  cmpDot: { width: 8, height: 8, borderRadius: 4 },
  cmpRank: { fontFamily: "Inter_600SemiBold", fontSize: 12, width: 14, textAlign: "center" },
  cmpName: { fontSize: 12, flex: 1 },
  cmpBarWrap: { flex: 1, height: 8, backgroundColor: "#E8E0D4", borderRadius: 4, overflow: "hidden" },
  cmpBar: { height: 8, borderRadius: 4 },
  cmpAmount: { fontFamily: "Inter_700Bold", fontSize: 12, width: 50, textAlign: "right" },
});
